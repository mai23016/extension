import * as vscode from 'vscode';
import axios from 'axios'; // Make sure to include the axios package

export function activate(context: vscode.ExtensionContext) {

  let disposable = vscode.commands.registerCommand('extension.connectToGPTAPI', async () => {
    //await vscode.window.showInputBox({      prompt: "Enter your message for the chat",    });
    // Initialize a simple state to store chat messages
    //let chatHistory: string[] = [];
    let chatHistory = [{
      role: 'system',
      content: "Your answers will be inserted as comments into a computer program so they must be declaired as comments with the use of the appropriate characters."
    }];

    const activeEditor = vscode.window.activeTextEditor;

    if (!activeEditor) {
      vscode.window.showInformationMessage('No active editor');
      return;
    }

    const selection = activeEditor.selection;
    const selectedText = activeEditor.document.getText(selection);

    const userInput = selectedText;

    if (!selectedText) {
      vscode.window.showInformationMessage('No text selected');
      return;
    }

    // Do something with the selected text
    //vscode.window.showInformationMessage(`Selected text: ${selectedText}`);

    // If no input was provided, show an error message
    if (!userInput) {
      vscode.window.showErrorMessage("No input provided");
      return;
    }

    // Update the chat history
    //chatHistory.push(`Human: ${userInput}`);
    //chatHistory.push(`AI:`); // We anticipate the AI's response
    chatHistory.push({
      role: 'user',
      content: userInput
    });
    
    // Define the API request parameters
    const apiEndpoint = 'https://api.openai.com/v1/chat/completions';
    const headers = {
      'Authorization': `Bearer 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`, // Replace with your actual API Key
      'Content-Type': 'application/json',
    };

    // Construct the conversation payload
    //messages: chatHistory.map(message => ({ role: message.startsWith('Human:') ? 'user' : 'assistant', content: message.substring(message.indexOf(':') + 1).trim() })),
    const payload = {
      model: 'ft:gpt-3.5-turbo-1106:personal::8Sj4PNIP', // The GPT-3.5-turbo model is used for chat completions
      messages: chatHistory,
      max_tokens: 500,
      temperature: 0.9 // Set to a level that makes sense for your use case
    };

    try {
      // Make the HTTP request to the GPT API
      const response = await axios.post(apiEndpoint, payload, { headers: headers });

      // Process the response and display the result
      const aiResponse = response.data.choices[0].message.content.trim();

      // Add the AI message to the chat history
      chatHistory.push({
        role: 'assistant',
        content: aiResponse,
      });

      // Insert the response below the caret
      const position = activeEditor.selection.active;
      const newPosition = position.with(position.line + 1, 0);
      const newSelection = new vscode.Selection(newPosition, newPosition);

      activeEditor.edit(editBuilder => {
      editBuilder.insert(newPosition, aiResponse + "\n");
      }).then(success => {
        if (success) {
          activeEditor.selection = newSelection;
        } else {
          vscode.window.showErrorMessage('Could not insert text');
        }
      });

      //vscode.window.showInformationMessage(`AI: ${aiResponse}`);

      // Update the chat history with the AI response
      //chatHistory[chatHistory.length - 1] = `AI: ${aiResponse}`;
    } catch (error: unknown) {
        let errorMessage: string;
      
        // Check if the error is an instance of AxiosError
        if (axios.isAxiosError(error)) {
          // If there is a response with a status code, construct a detailed error message
          if (error.response) {
            errorMessage = `Server responded with status code ${error.response.status}: ${error.response.data}`;
          } else if (error.request) {
            // The request was made but no response was received
            errorMessage = 'No response received from the server';
          } else {
            // Something happened in setting up the request that triggered an error
            errorMessage = error.message;
          }
        } else {
          // If it's not an AxiosError, it could be an error thrown by some other means
          errorMessage = (error instanceof Error) ? error.message : 'An unknown error occurred';
        }
      
        vscode.window.showErrorMessage(`Error connecting to GPT API: ${errorMessage}`);
      }
  });


  let disposable2 = vscode.commands.registerCommand('extension.debuggingByGPTAPI', async () => {
    // Prompt the user for input
    //const userInput = 
    //await vscode.window.showInputBox({      prompt: "Enter your message for the chat",    });
    // Initialize the chat history with a specific system message to start the conversation
    let chatHistory = [{
        role: 'system',
        content: "Do not use natural language in your replies, your answers should always include only code, nothing else. You must also provide explanatory comments. Only fix the errors, leaving the rest of the code unaltered."
    }];

    const activeEditor = vscode.window.activeTextEditor;

    if (!activeEditor) {
      vscode.window.showInformationMessage('No active editor');
      return;
    }

    const selection = activeEditor.selection;
    const selectedText = selection.isEmpty
      ? activeEditor.document.getText()  // No selection, get entire document
      : activeEditor.document.getText(selection);  // There is a selection, get selected text only
 
    let rangeToReplace = selection.isEmpty
      ? new vscode.Range( // If there is no selection, create a range that represents the entire document
          activeEditor.document.positionAt(0),
          activeEditor.document.positionAt(activeEditor.document.getText().length)
        )
      : selection; // If there is a selection, use it as the range to replace

    const userInput = "There are bugs in the following code, could you fix them?\r\n" + selectedText;

    if (!selectedText) {
      vscode.window.showInformationMessage('No text selected');
      return;
    }

    // Do something with the selected text
    //vscode.window.showInformationMessage(`Selected text: ${selectedText}`);

    // If no input was provided, show an error message
    if (!userInput) {
      vscode.window.showErrorMessage("No input provided");
      return;
    }

    // Add the user's message to chatHistory
    chatHistory.push({
        role: 'user',
        content: userInput
      });

    // Define the API request parameters
    const apiEndpoint = 'https://api.openai.com/v1/chat/completions';
    const headers = {
      'Authorization': `Bearer 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`, // Replace with your actual API Key
      'Content-Type': 'application/json',
    };

    // Construct the conversation payload
    const payload = {
      model: 'ft:gpt-3.5-turbo-1106:personal::8Siqs1QE', // The GPT-3.5-turbo model is used for chat completions
      messages: chatHistory,
      max_tokens: 500,
      temperature: 0.9 // Set to a level that makes sense for your use case
    };

    try {
      // Make the HTTP request to the GPT API
      const response = await axios.post(apiEndpoint, payload, { headers: headers });

      // Process the response and display the result
      const aiResponse = response.data.choices[0].message.content.trim();

      // Add the AI message to the chat history
      chatHistory.push({
        role: 'assistant',
        content: aiResponse,
      });

      // Replace the selected text with the model's response
    activeEditor.edit(editBuilder => {
        editBuilder.replace(rangeToReplace, aiResponse);
      }).then(success => {
        if (success) {
          // Optionally, you can select the newly inserted text
          const newSelection = new vscode.Selection(rangeToReplace.start, rangeToReplace.start.translate(0, aiResponse.length));
          activeEditor.selection = newSelection;
        } else {
          vscode.window.showErrorMessage('Could not replace text');
        }
      });

      //vscode.window.showInformationMessage(`AI: ${aiResponse}`);

    } catch (error: unknown) {
        let errorMessage: string;
        if (axios.isAxiosError(error)) {
          if (error.response) {
            errorMessage = `Server responded with status code ${error.response.status}: ${error.response.data}`;
          } else if (error.request) {
            errorMessage = 'No response received from the server';
          } else {
            errorMessage = error.message;
          }
        } else if (error instanceof Error) {
          errorMessage = error.message;
        } else {
          errorMessage = 'An unknown error occurred';
        }
  
        vscode.window.showErrorMessage(`Error connecting to GPT API: ${errorMessage}`);
      }
  });


  let disposable3 = vscode.commands.registerCommand('extension.analysisByGPTAPI', async () => {
        // Prompt the user for input
    //const userInput = 
    //await vscode.window.showInputBox({      prompt: "Enter your message for the chat",    });
    // Initialize the chat history with a specific system message to start the conversation
    let chatHistory = [{
      role: 'system',
      content: "You will be presented with some snippets of code to analyze. In your answers you should include: 1. the code with some inserted explanatory comments, 2. a section explaining the functionality of the code and 3. Some software metrics regarding the code."
  }];

  const activeEditor = vscode.window.activeTextEditor;

  if (!activeEditor) {
    vscode.window.showInformationMessage('No active editor');
    return;
  }

  const selection = activeEditor.selection;
  const selectedText = selection.isEmpty
    ? activeEditor.document.getText()  // No selection, get entire document
    : activeEditor.document.getText(selection);  // There is a selection, get selected text only

  let rangeToReplace = selection.isEmpty
    ? new vscode.Range( // If there is no selection, create a range that represents the entire document
        activeEditor.document.positionAt(0),
        activeEditor.document.positionAt(activeEditor.document.getText().length)
      )
    : selection; // If there is a selection, use it as the range to replace

  const userInput = "Could you examine the following code, insert some comments, explain its functionality and calculate some software metrics?\r\n" + selectedText;

  if (!selectedText) {
    vscode.window.showInformationMessage('No text selected');
    return;
  }

  // Do something with the selected text
  //vscode.window.showInformationMessage(`Selected text: ${selectedText}`);

  // If no input was provided, show an error message
  if (!userInput) {
    vscode.window.showErrorMessage("No input provided");
    return;
  }

  // Add the user's message to chatHistory
  chatHistory.push({
      role: 'user',
      content: userInput
    });

  // Define the API request parameters
  const apiEndpoint = 'https://api.openai.com/v1/chat/completions';
  const headers = {
    'Authorization': `Bearer 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`, // Replace with your actual API Key
    'Content-Type': 'application/json',
  };

  // Construct the conversation payload
  const payload = {
    model: 'ft:gpt-3.5-turbo-1106:personal::8SiZIrqo', // The GPT-3.5-turbo model is used for chat completions
    messages: chatHistory,
    max_tokens: 500,
    temperature: 0.9 // Set to a level that makes sense for your use case
  };

  try {
    // Make the HTTP request to the GPT API
    const response = await axios.post(apiEndpoint, payload, { headers: headers });

    // Process the response and display the result
    const aiResponse = response.data.choices[0].message.content.trim();

    // Add the AI message to the chat history
    chatHistory.push({
      role: 'assistant',
      content: aiResponse,
    });

    // Replace the selected text with the model's response
  activeEditor.edit(editBuilder => {
      editBuilder.replace(rangeToReplace, aiResponse);
    }).then(success => {
      if (success) {
        // Optionally, you can select the newly inserted text
        const newSelection = new vscode.Selection(rangeToReplace.start, rangeToReplace.start.translate(0, aiResponse.length));
        activeEditor.selection = newSelection;
      } else {
        vscode.window.showErrorMessage('Could not replace text');
      }
    });

    //vscode.window.showInformationMessage(`AI: ${aiResponse}`);

  } catch (error: unknown) {
      let errorMessage: string;
      if (axios.isAxiosError(error)) {
        if (error.response) {
          errorMessage = `Server responded with status code ${error.response.status}: ${error.response.data}`;
        } else if (error.request) {
          errorMessage = 'No response received from the server';
        } else {
          errorMessage = error.message;
        }
      } else if (error instanceof Error) {
        errorMessage = error.message;
      } else {
        errorMessage = 'An unknown error occurred';
      }

      vscode.window.showErrorMessage(`Error connecting to GPT API: ${errorMessage}`);
    }
  });


  context.subscriptions.push(disposable, disposable2);
}

export function deactivate() {
  // Cleanup if necessary
}